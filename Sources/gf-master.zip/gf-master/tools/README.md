# Tools with gf

This directory contains some tools made with Gamedev Framework.

## gf Info

A non-graphical application to display some useful information about the system.

## Other tools

You can find other tools in the [gf-tools](https://github.com/GamedevFramework/gf-tools) repository.
