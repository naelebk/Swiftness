# Developers

Julien Bernard
  julien dot bernard at univ dash fcomte dot fr


# Contributors

- Lilian Franchi (@Xeryko), game widgets
- Sherjil Ozair (@sherjilozair), macos support
- Simonin Remi (@NiiRoZz), widgets ui
