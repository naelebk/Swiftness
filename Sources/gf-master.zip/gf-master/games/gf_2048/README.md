# gf 2048

## How to play

- Arrows: Move the tiles
- F: Toggle fullscreen
- Escape: Stop the game

## Screenshot

![gf 2048](gf_2048.png)

## Authors

- Julien Bernard

## License

gf 2048 is licensed under the terms and conditions of the [zlib/libpng license](https://opensource.org/licenses/Zlib).

The ['Clear Sans'](https://01.org/clear-SANS) font is licensed under the terms and conditions of the [Apache 2.0 license](https://opensource.org/licenses/Apache-2.0).
