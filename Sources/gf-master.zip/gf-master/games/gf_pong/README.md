# gf Pong!

## How to play

- S/X: Up/Down for the left paddle
- Up/Down: Up/Down for the right paddle
- F: Toggle fullscreen
- Escape: Stop the game

## Screenshot

![gf Pong!](gf_pong.png)

## Authors

- Julien Bernard

## License

gf Pong! is licensed under the terms and conditions of the [zlib/libpng license](https://opensource.org/licenses/Zlib).
