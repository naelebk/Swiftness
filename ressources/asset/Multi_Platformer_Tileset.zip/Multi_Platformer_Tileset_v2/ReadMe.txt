---------------------------------------
Multi Platformer Tileset
Version 5.0 - Cave Environment Update

Made and distributed by Shackhal
https://shackhal.itch.io/
2016-2022

---------------------------------------

Thank you very much for buying this tileset. It helps me to keep this going. Check the examples to see the capabilities of the tilesets. And create worlds with it :D

The license is CC0 (Creative Commons Zero), so the content is free to use in any personal, educational and commercial projects.
Giving credits (Diego del Solar and/or "Shackhal") is not mandatory, but greatly appreciated.

---------------------------------------

You can give feedback or add requests in the comments section.

In case you need more tiles, contact me.

Twitter: @shackhal
Website: https://shackhal.com/
Email: shackhalboss@gmail.com



